//
//  ViewController.swift
//  Malli_Exam02
//
//  Created by Malli,Bhavana on 4/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var courseInput: UITextField!
    
    @IBOutlet weak var idInput: UITextField!
    
    
    @IBOutlet weak var courseOutlet: UIButton!
    
    var Name = ""
    var Resultimage = ""
    var cid = 0
    var sid = 0
    var CourseFound = CourseDetails()
    var courseArray = CoursesArray
    
    @IBOutlet weak var dispalylabel: UILabel!
    
    @IBOutlet weak var displayimage: UIImageView!
    
    
    @IBOutlet weak var enrollOutlet: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        courseOutlet.isEnabled = false
        enrollOutlet.isHidden = true
    }
    
    @IBAction func inputCourse(_ sender: Any) {
        if courseInput.hasText{
            cid = 1
        }
    }
    
    
    @IBAction func inputStudent(_ sender: Any) {
        if idInput.hasText{
            sid = 1
        }
        if (cid == 1 && sid == 1){
            courseOutlet.isEnabled = true
        }
    }
    
    
    @IBAction func CourseCheckButtn(_ sender: UIButton) {
        let courseit = courseInput.text!
        var crse = false
        
        for course in courseArray{
            if courseit == course.courseID{
                crse = true
                dispalylabel.text = courseit + " is open for registrations"
                enrollOutlet.isHidden = false
                displayimage.isHidden = false
                displayimage.image = UIImage(named: course.courseImage)
                Name = course.courseName
                Resultimage = course.courseImage
                
            }
          /*  else{
                 
             }*/
        }
        if crse == false{
            dispalylabel.text = "Course Id not found"
            enrollOutlet.isHidden = true
            displayimage.isHidden = false
            displayimage.image = UIImage(named: "default")
        }
        }
        
        
        
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        
        if transition == "ResultSegue"{
            var destination = segue .destination as! ResultViewController
            destination.studentsid = idInput.text!
            destination.crses = courseInput.text!
            destination.Name = Name
            destination.Resultimage = Resultimage
            
        }
        
        courseInput.text = ""
        idInput.text = ""
        enrollOutlet.isHidden = true
        dispalylabel.text = ""
        displayimage.isHidden = true
        courseOutlet.isEnabled = false
    }

}
    

