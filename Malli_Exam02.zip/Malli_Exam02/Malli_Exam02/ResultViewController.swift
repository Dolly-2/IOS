//
//  ResultViewController.swift
//  Malli_Exam02
//
//  Created by Malli,Bhavana on 4/11/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var resultlabel: UILabel!
    
    
    @IBOutlet weak var successlabel: UILabel!
    
    
    @IBOutlet weak var rsultimage: UIImageView!
    
    var studentsid = ""
    var crses = ""
    var Name = ""
    var Resultimage = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resultlabel.text! = "Your Student ID is :\(studentsid)"
        successlabel.text! = "You have successfully enrolled in \(crses),\(Name)"
        rsultimage.image = UIImage(named: Resultimage)
        
        var width = rsultimage.frame.width
        width += 40
        var height = rsultimage.frame.height
        height += 40
        
        var x  =  rsultimage.frame.origin.x-20
        
        
        var y = rsultimage.frame.origin.y-20
        
        var largeFrame = CGRect(x: x, y: y, width: width, height: height)
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 70, animations: {
            self.rsultimage.frame = largeFrame
        })
        
        // Do any additional setup after loading the view.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    
}
