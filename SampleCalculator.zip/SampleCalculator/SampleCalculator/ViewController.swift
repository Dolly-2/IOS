//
//  ViewController.swift
//  SampleCalculator
//
//  Created by Malli,Bhavana on 2/2/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var displayLabel: UILabel!
    var operand1:Double = -1.1
    var _operator:Character = " "
    var operand2:Double = -1.1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
   
    @IBAction func button5Clicked(_ sender: Any) {
        displayLabel.text = displayLabel.text! + "5"
        if(operand1 == -1.1){
            operand1 = 5
        }
        else{
            operand2 = 5
        }
       
    }
    
    
    @IBAction func buttonPlusClicked(_ sender: Any) {
        displayLabel.text = displayLabel.text! + "+"
        
        if(_operator == " "){
            _operator = "+"
        }
        
        
    }
    
    
    @IBAction func button3Clicked(_ sender: Any) {
        displayLabel.text = displayLabel.text! + "3"
        if(operand2 == -1.1){
            operand2 = 3
        }
        else{
            operand1 = 3
        }
        
    }
    
    
    @IBAction func buttonEClicked(_ sender: Any) {
        displayLabel.text = displayLabel.text! + "="
        if _operator == "+"{
            displayLabel.text = displayLabel.text!+"\(operand1 + operand2)"
        }
    }
    

}

