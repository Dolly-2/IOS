//
//  MovieCollectionViewCell.swift
//  Malli_Movies
//
//  Created by Malli,Bhavana on 4/28/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    
    func assignMovie(with m: Movie){
            imageViewOutlet.image = m.image
        
    }
    
}
