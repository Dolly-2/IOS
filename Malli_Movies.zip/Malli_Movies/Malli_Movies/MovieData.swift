//
//  MovieData.swift
//  Malli_Movies
//
//  Created by Malli,Bhavana on 4/28/23.
//

import Foundation
import UIKit


struct Movie{
    var title : String
    var image :UIImage
    var releasedYear  : String
    var movieRating : String
    var boxOffice : String
    var moviePlot : String
    var cast = [String]()
}
struct Genre{
    var category :String
    var movies : [Movie] = []
    
}


let movie1 = Genre(category: "Romance", movies: [Movie(title: "Murari", image: UIImage(named: "Murari")!, releasedYear: "2001", movieRating: "9.5", boxOffice: "244M", moviePlot: "In nineteenth century, during the Amavasya phase, considered to be inauspicious, a greedy alcoholic Zamindar intrudes the temple to steal the idol of principal deity Durga.", cast: ["Mahesh Babu","Sonali Bindre"]),Movie(title: "Love Today", image: UIImage(named: "Love Today")!, releasedYear: "2022", movieRating: "9.8", boxOffice: "250M", moviePlot: "Uthaman Pradeep, a 24-year-old support engineer employed in Cognizant in Chennai has been in a romantic relationship with Nikitha, daughter of Adv.", cast: ["Pradeep Ranganathan","Ivana"]),Movie(title: "Tholi Prema", image: UIImage(named: "Tholi Prema")!, releasedYear: "2019", movieRating: "10", boxOffice: "500M", moviePlot: "Aditya and Varsha are irresistibly drawn to one another but their individual ideologies keep getting in the way of their romance.", cast: ["Varun Tej","Rashi Kanna"]),Movie(title: "Geetha Govindam", image: UIImage(named: "Geetha Govindam")!, releasedYear: "2018", movieRating: "10", boxOffice: "1B", moviePlot: "At midnight, Nithya's car breaks down and she seeks help from a bypasser Vijay Govind.", cast: ["Vijay Devarakonda","Rashmika Mandanna"]),Movie(title: "Arjun Reddy", image: UIImage(named: "Arjun Reddy")!, releasedYear: "2017", movieRating: "8.9", boxOffice: "430M", moviePlot: "Arjun Reddy Deshmukh is a house surgeon at St. Mary's Medical College in Mangalore, India.", cast: ["Vijay Devarakonda","Shalini Pandey"])]);


let movie2 = Genre(category: "Horror", movies: [Movie(title: "Masooda", image: UIImage(named: "Masooda")!, releasedYear: "2023", movieRating: "8.9", boxOffice: "431M", moviePlot: "In 2022, Neelam and her daughter Nazia are tenants in an apartment behind the building.", cast: ["Sangeetha","Thiruveer"]),Movie(title: "Kanchana", image: UIImage(named: "Kanchana")!, releasedYear: "2011", movieRating: "9.2", boxOffice: "312.4M", moviePlot: "Raghava, an unemployed youth, has developed an irrational phasmophobia and refuses to step out of his house.", cast: ["Raghava Lawrence","Navdeep "]),Movie(title: "Chandramukhi", image: UIImage(named: "Chandramukhi")!, releasedYear: "2005", movieRating: "9.4", boxOffice: "554.43M", moviePlot: "Saravanan, a psychiatrist from the United States, comes to meet his friend Senthilnathan, and his wife Ganga while on vacation.", cast: ["Rajinikanth","Jyothika"]),Movie(title: "Gruham", image: UIImage(named: "Gruham")!, releasedYear: "2019", movieRating: "9.1", boxOffice: "432.3M", moviePlot: "The movie starts with a series of incidents of a happy life of mom and a daughter back in 1934.", cast: ["Sidhartha","Andrea Jeremiah"]),Movie(title: "Avunu", image: UIImage(named: "Avunu")!, releasedYear: "2012", movieRating: "8.6", boxOffice: "234.4M", moviePlot: "Harsha's parents come to stay with them for a few days and also to make sure that the marriage is not consummated before a certain auspicious time.", cast: ["Raghu Babu","Shamna Kasim"])]);


let movie3 = Genre(category: "Comedy", movies: [Movie(title: "DJ Tillu", image: UIImage(named: "DJ Tillu")!, releasedYear: "2013", movieRating: "9.5", boxOffice: "343.4M", moviePlot: "Bala Gangadhar Tilak alias DJ Tillu, is a young man who wants be a DJ. One day, he meets Radhika in a club.", cast: ["Sidharth Jonnalagadda","Neha Shetty"]),Movie(title: "Jaathiratnalu", image: UIImage(named: "Jaathiratnalu")!, releasedYear: "2021", movieRating: "9.6", boxOffice: "455M", moviePlot: "Srikanth works in his father's ladies emporium in Jogipet.", cast: ["Naveen Polishetty", "Faria Abdulla"]),Movie(title: "Kithakithalu", image: UIImage(named: "Kithakitalu")!, releasedYear: "2006", movieRating: "9.0", boxOffice: "674M", moviePlot: "Relangi Rajababu is such a that he files a case against a girl who attempted to harass him.", cast: ["Allari Naresh", "Geetha Singh"]),Movie(title: "Aha Na Pelli Anta", image: UIImage(named: "ANPA")!, releasedYear: "1987", movieRating: "9.5", boxOffice: "242.6M", moviePlot: "Satyanarayana is worried about Krishnamurthy's marriage, so much so that he imagines every young woman who happens to be seen by him as his daughter-in-law.", cast: ["Rajendra Prasad","Rajini"]),Movie(title: "Prema Katha Chitram", image: UIImage(named: "PKC")!, releasedYear: "2019", movieRating: "8.8", boxOffice: "443.6M", moviePlot: "The movie starts with Sudheer Babu, Praveen and Nanditha plan a group suicide because of their failures in their respective lives.", cast: ["Sudheer Babu","Nanditha"])]);


var movies_Array = [movie1,movie2,movie3]

