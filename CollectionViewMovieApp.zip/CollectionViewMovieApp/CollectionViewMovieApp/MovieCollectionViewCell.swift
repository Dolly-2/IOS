//
//  MovieCollectionViewCell.swift
//  CollectionViewMovieApp
//
//  Created by Malli,Bhavana on 4/20/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    func  assignMovie(with movie: Movie){
        imageViewOutlet.image = movie.image
        
        }
     
}
