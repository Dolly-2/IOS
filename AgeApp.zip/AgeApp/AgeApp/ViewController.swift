//
//  ViewController.swift
//  AgeApp
//
//  Created by Malli,Bhavana on 1/25/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var nameinputoutlet: UITextField!
    
    
    @IBOutlet weak var ageinputoutlet: UITextField!
    
    
    @IBOutlet weak var displayoutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func displayaction(_ sender: Any) {
        
        var input = nameinputoutlet.text!
        
        var input1 = ageinputoutlet.text!
        
        displayoutlet.text = "Hello, \(input)!! your age is : \(input1) "
        
        
    }
    

}

