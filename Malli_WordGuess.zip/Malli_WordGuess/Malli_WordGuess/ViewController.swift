//
//  ViewController.swift
//  Malli_WordGuess
//
//  Created by Malli,Bhavana on 3/30/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    
    @IBOutlet weak var hintLabel: UILabel!
    
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var guessALetterButtonOutlet: UIButton!
    
    
    @IBOutlet weak var playAgainButtonOutlet: UIButton!
    
    
    var words = [["pizza", "Food"],
                 ["Parrot", "Birds"],
                 ["Car", "four wheeler"],
                 ["Watch", "Gadgets"],
                 ["TajMahal", "India"]]
    
    var guess = 0
    var word = ""
    var lettersGuessed = ""
    var count = 0
    let maxNumOfWrongGuesses = 10;
    var correct = 0
    

    @IBAction func inputletter(_ sender: Any) {
        
        //Read the data from the text field
               var textEnterd = guessLetterField.text!;
               //Consider only the last character by calling textEntered.last and trimming the white spaces.
               textEnterd = String(textEnterd.last ?? " ").trimmingCharacters(in: .whitespaces)
               guessLetterField.text = textEnterd
               
               //Check whether the entered text is empty or not to enable check button.
               if textEnterd.isEmpty{
                   guessALetterButtonOutlet.isEnabled = false
               }
               else{
                   guessALetterButtonOutlet.isEnabled = true
               }
    }
    
    
    
    @IBAction func guessLetterButtonPressed(_ sender: Any) {
        
        var letter = guessLetterField.text!
        lettersGuessed = lettersGuessed + letter
        var revealedWord : String = ""
        for l in word{
                    if lettersGuessed.contains(l){
                        revealedWord += "\(l)"
                    }
                    else{
                        revealedWord += "_ "
                    }
                }
        count += 1
                //Assigning the word to guessLetterField after a guess
        userGuessLabel.text = revealedWord
        guessLetterField.text = ""
        guessCountLabel.text = "you have made \(count) guesses"
        if(count < maxNumOfWrongGuesses){
        //If the word is guessed correctly, we are enabling play again button and disabling the check button.
        if(userGuessLabel.text!.contains("_") == false){
            
            guessALetterButtonOutlet.isEnabled = false
            playAgainButtonOutlet.isHidden = false
            displayImage.image = UIImage(named: words[guess][0])
            guessCountLabel.text = "WOW! you have made \(count) guesss to guess the word!"
            correct += 1
            wordsGuessedLabel.text = "Total number of words guessed successfully : \(correct)"
            wordsRemainingLabel.text = "Total number of words remaining in game : \(words.count - correct)"
            totalWordsLabel.text = "Total number of words in game : \(words.count)"
        }
        guessALetterButtonOutlet.isEnabled = false
        
        }
        else{
            guessCountLabel.text = "You have used all the available guesses, Please play again"
            playAgainButtonOutlet.isHidden = false
            guessALetterButtonOutlet.isEnabled = false
            guess -= 1
        }
       
    }
    
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
        playAgainButtonOutlet.isHidden = true
        lettersGuessed = ""
                guess += 1
                //if count reaches the end of the array (all the words are guessed sucessfully), then print Congratualtions in the status label.
                if guess == words.count{
                    guessCountLabel.text = ""
                    statusLabel.text = "Congruations! You are done with the game! \nPlease startover again"
                    //clearing the labels.
                    userGuessLabel.text = ""
                    hintLabel.text = ""
                    displayImage.image = UIImage(named: "alldone")
                    playAgainButtonOutlet.isHidden = false
                    //top()
                }
                else{
                    //fetch the next word from the array
                    word = words[guess][0]
                    //fetch the hint related to the word
                    hintLabel.text = "Hint: "
                    hintLabel.text! += words[guess][1]
                    //Enabling the check button.
                    guessALetterButtonOutlet.isEnabled = true
                    guessCountLabel.text = ""
                    userGuessLabel.text = ""
                    for letter in word{
                        userGuessLabel.text! += "_ "
                    }
                    displayImage.image = UIImage()
                    count = 0
                }
        if(correct == words.count){
            correct = 0
            wordsGuessedLabel.text = "Total number of words guessed successfully : \(correct)"
            wordsRemainingLabel.text = "Total number of words remaining in game : \(words.count - correct)"
            totalWordsLabel.text = "Total number of words in game : \(words.count)"
            guess = -1
            count = 0
            
        }
        if guess == 0{
            statusLabel.text = ""
        }
    
    
    
    
    }
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        word = words[guess][0]
        wordsGuessedLabel.text = "Total number of words guessed successfully : \(correct)"
        wordsRemainingLabel.text = "Total number of words remaining in game : \(words.count - correct)"
        totalWordsLabel.text = "Total number of words in game : \(words.count)"
        guessALetterButtonOutlet.isEnabled = false
        hintLabel.text = "Hint: "+words[guess][1];
        statusLabel.text = ""
        guessCountLabel.text = "You had made \(guess) guessess"
        for letter in word{
            userGuessLabel.text! += "_ "
        }
    }


}

