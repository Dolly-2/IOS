//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Malli,Bhavana on 3/16/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var crsNumber: UILabel!
    
    
    @IBOutlet weak var crcTitle: UILabel!
    
    
    @IBOutlet weak var semOffered: UILabel!
    
    
    @IBOutlet weak var inputImage: UIImageView!
    
    
    @IBOutlet weak var nextBtn: UIButton!
    
    var imageNumber = 0
    
    
    @IBOutlet weak var prevBtn: UIButton!
    
    let Courses = [["img01", "44555", "Network Security", "Fall 2022"],["img02", "44643", "ios", "Spring 2023"],["img03", "44656", "Streaming Data", "Fall 2024"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //load the first image(image in the 0th position)
        inputImage.image = UIImage(named: Courses[0][0])
        
        crsNumber.text = Courses[0][1]
        crcTitle.text = Courses[0][2]
        semOffered.text = Courses[0][3]
        
        //previous button disabled
        prevBtn.isEnabled = false
        
        //next button is enabled
        nextBtn.isEnabled = true
        
    }

    @IBAction func nextBtncClicked(_ sender: UIButton) {
        //increment the image number
        imageNumber += 1
        
        //update the details of next course (image,num,title,sem offered)
        inputImage.image = UIImage(named: Courses[imageNumber][0])
                 crsNumber.text = Courses[imageNumber][1]
                   crcTitle.text = Courses[imageNumber][2]
                semOffered.text = Courses[imageNumber][3]
        
        //previous button should be enabled
        prevBtn.isEnabled = true
        
        //when we reach the end of array next button should be disabled
        if(imageNumber == Courses.count-1){
            //reach the end of array
            nextBtn.isEnabled = false
            
        }
        
    }
    
    
    @IBAction func previousBtnClicked(_ sender: UIButton) {
        //decrement the imge number
        imageNumber -= 1
        
        //update the course details
        inputImage.image = UIImage(named: Courses[imageNumber][0])
        crsNumber.text = Courses[imageNumber][1]
        crcTitle.text = Courses[imageNumber][2]
        semOffered.text = Courses[imageNumber][3]
        
        
        nextBtn.isEnabled = true
        
        //once you reach starting of array disable the previous btn
        if(imageNumber == 0){
            prevBtn.isEnabled = false
            
        }
    }
        
//        func updateCourseDetails(_ imageNumber:Int){
//            inputImage.image = UIImage(named: Courses[imageNumber][0])
//            crsNumber.text = Courses[imageNumber][1]
//            crcTitle.text = Courses[imageNumber][2]
//            semOffered.text = Courses[imageNumber][3]
//
//            }
       
        
    
    
}

