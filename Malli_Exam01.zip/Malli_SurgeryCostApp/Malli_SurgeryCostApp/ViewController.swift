//
//  ViewController.swift
//  Malli_SurgeryCostApp
//
//  Created by Malli,Bhavana on 2/28/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var InputNameOL: UITextField!
    
    
    @IBOutlet weak var TypeOfSurgeryOL: UITextField!
    
    
    @IBOutlet weak var CostInputOL: UITextField!
    
    
    @IBOutlet weak var ImageViewOL: UIImageView!
    
    
    @IBOutlet weak var displayInputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func CalButton(_ sender: Any) {
        var Surgery_cost : Double = 0.0
        var tax : Double = 0.0
        var Health_Insurence : Double = 0.0
        var Surgery_Type : String = " "
        var  Total_Surger_cost : Double = 0.0
        Total_Surger_cost = Double( (Surgery_cost)*(1+tax)-(Health_Insurence))
        
        
        
    if(InputNameOL.isEnabled == false || TypeOfSurgeryOL.isEnabled == false || CostInputOL.isEnabled == false ){
            
            ImageViewOL.image = UIImage(named:"noResults")
        displayInputOL.text = "Enter All Details "
            
        }
        else if(Surgery_Type == " Heart " && Surgery_cost == 3000.5 && tax == 11.75 && Health_Insurence == 500   ){
           ImageViewOL.image = UIImage(named: "Heart")
            
            displayInputOL.text = " \(InputNameOL) : \r Total cost for Heart 🫀 surger is $\(Total_Surger_cost)"
            }
        else if(Surgery_Type == " Brain " && Surgery_cost == 5500.8 && tax == 13.5 && Health_Insurence == 750   ){
            ImageViewOL.image = UIImage(named: "Brain")
            displayInputOL.text = " \(InputNameOL) : \r Total cost for Brain 🧠 surger is $\(Total_Surger_cost)"
            }
        else if(Surgery_Type == " Knee replacement " && Surgery_cost == 1500.75 && tax == 6.25 && Health_Insurence == 350  ){
            ImageViewOL.image = UIImage(named: "Knee")
            displayInputOL.text = " \(InputNameOL) : \r Total cost for Knee surger is $\(Total_Surger_cost)"
            
            }
        
       
        
        
        
        
        
    }
    

}

