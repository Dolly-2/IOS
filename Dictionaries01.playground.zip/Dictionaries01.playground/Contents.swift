import UIKit
var Capitals = ["Arkansas":"LittleRock","Georgia":"Atlanta","Missouri":"Jeff Ci†y"]
print(Capitals)
print(Capitals.count)
Capitals["Texas"] = "Austin"
print(Capitals)
print(Capitals.count)

var Numbers = [5:"three",2:"six",3:"eigh†"]
print(Numbers)
print(Numbers.count)
Numbers[76] = "Ten"
print(Numbers)
print(Numbers.count)

var Courses = [44542:"Java",44560:"IOS",44765:"PM"]
print(Courses)
print(Courses.count)
Courses[44560] = "Database"
print(Courses)
print(Courses[44560]!)
Courses.removeValue(forKey:44542)
print(Courses)

for(key,vlue) in Courses{
    print(key)
}
for(key,value) in Courses{
    print(value)
}
for(key,value) in Courses{
    print("courseID :\(key ) CourseName :\(value)")
}

