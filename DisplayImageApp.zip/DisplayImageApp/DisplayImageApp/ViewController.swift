//
//  ViewController.swift
//  DisplayImageApp
//
//  Created by Malli,Bhavana on 2/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var ImageViewOL: UIImageView!
    
    
    @IBOutlet weak var descriptionLabelOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func displayImage(_ sender: Any) {
        //To Display an image
        ImageViewOL.image = UIImage(named:"Rohit")
        //To display text regarding an image
        //descriptionLabelOL.text = "Captan of cricket world cup 2019"
        descriptionLabelOL.text = "Machaa HitMan"
        
    }
   
    
    

}

