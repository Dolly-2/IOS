import UIKit
let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

