import UIKit
var players : Set<String> = ["VK","Max","KL"]
print(players)
print(players.count)
print(players.contains("kane"))
players.insert("Kane")
print(players)
players.remove("Kane")
print(players)

var numbers : Set<Int> = [2,4,6,8]
var numbers1 : Set<Int> = [1,3,5,7]

var unionSet : Set<Int> =  numbers.union(numbers1)
print(unionSet)

var intersectionSet : Set<Int> = numbers.intersection(numbers1)
print(intersectionSet)

var subtractionSet : Set<Int> = numbers.subtracting(numbers1)
print(subtractionSet)

var symmDiffSet : Set<Int> = numbers1.symmetricDifference(numbers)
print(symmDiffSet)

print((numbers.isSubset(of: numbers1)))
