import UIKit

let alphabet:Character="a"
switch alphabet {
case "a","A":
print("It is alphabet a or A")
case "b":
print("It is lower alphabet b")
case "C":
print("It is upper case alphabet C")
default:
print("None of the cases are executed above")
}

print("**********")

let isVowel:Character="e"
switch isVowel {
case "a","e","i","o","u":
print("The alphabet is a lower case vowel")
case "A","E","I","O","U":
    print("The alphabet is an upper case vowel")
default:
print("The alphabet is a consonant")
}

let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

