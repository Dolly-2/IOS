//
//  ViewController.swift
//  SalaryMulViewControllers
//
//  Created by Malli,Bhavana on 4/4/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var NameOutlet: UITextField!
    
    
    @IBOutlet weak var ComapanyOutlet: UITextField!
    
    
    @IBOutlet weak var salaryOutlet: UITextField!
    
    var totalsalary = 0.0
    var annum : Double = 12.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func calSalaryBtnClicked(_ sender: Any) {
        
        var Name = (NameOutlet.text!)
        print(Name)
        
        var company = (ComapanyOutlet.text!)
        print(company)
        
        var totasal = Double(salaryOutlet.text!)
        print(totasal)
        
        totalsalary = totasal! * 12.0
        print(totalsalary)
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            var transition = segue.identifier
            
            if transition == "ResultSegue"{
                var destination = segue .destination as! ResultViewController
                
                destination.Name = NameOutlet.text!
                destination.company = ComapanyOutlet.text!
                destination.totsal = salaryOutlet.text!
                destination.totsalary = String (totalsalary)
                
//                amountOutlet.text = ""
//                discountRateOutlet.text = ""
                
            }
        }
    

}

