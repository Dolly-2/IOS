//
//  ResultViewController.swift
//  SalaryMulViewControllers
//
//  Created by Malli,Bhavana on 4/4/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var displayNmaeOutlet: UILabel!
    
    
    @IBOutlet weak var displayCompanyOutlet: UILabel!
    
    
    @IBOutlet weak var displayenteredSalary: UILabel!
    
    
    @IBOutlet weak var displayResultOutlet: UILabel!
    
    var Name = ""
    var company = ""
    var totsal = ""
    var totsalary = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        displayNmaeOutlet.text = displayNmaeOutlet.text! + Name
                
                
        displayCompanyOutlet.text = displayCompanyOutlet.text! +
        company
        
        displayenteredSalary.text = displayenteredSalary.text! +
        totsal
        
        displayResultOutlet.text = displayResultOutlet.text! + totsalary
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
