//
//  ViewController.swift
//  DiscountAppWithMulControllers
//
//  Created by Malli,Bhavana on 4/3/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var amountOutlet: UITextField!
    
    
    @IBOutlet weak var discountRateOutlet: UITextField!
    
    var priceAfterDiscount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func calcButtonClicked(_ sender: UIButton) {
        var amount = Double(amountOutlet.text!)
        print(amount!)
                
        var discRate = Double(discountRateOutlet.text!)
        print(discRate!)
                
        priceAfterDiscount = amount! - (amount!*discRate!/100)
        print(priceAfterDiscount )
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            var transition = segue.identifier
            
            if transition == "ResultSegue"{
                var destination = segue .destination as! ResultViewController
                
                destination.amount = amountOutlet.text!
                destination.discRate = discountRateOutlet.text!
                destination.priceAfterDisc = String (priceAfterDiscount)
                
//                amountOutlet.text = ""
//                discountRateOutlet.text = ""
                
            }
        }
    

}

