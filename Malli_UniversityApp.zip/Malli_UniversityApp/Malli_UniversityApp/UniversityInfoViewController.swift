//
//  UniversityInfoViewController.swift
//  Malli_UniversityApp
//
//  Created by Malli,Bhavana on 4/20/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {
    
    var university : college?
        var img_info = ""
        var lab_info = ""
        var name_info = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = university?.universityName
                print(university)

        // Do any additional setup after loading the view.
        universityInfoOutlet.isHidden = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        universityImageViewOutlet.image = UIImage(named:(university?.universityimg)!)
        universityImageViewOutlet.frame.origin.x = view.frame.maxX
        UIView.animate(withDuration: 1, animations: {
            self.universityImageViewOutlet.center.x = self.view.center.x})
        
    }
    
    
    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    
    @IBAction func showInfoAction(_ sender: UIButton) {
        universityInfoOutlet.isHidden = false
        universityInfoOutlet.text! = (university?.universityinfo)!
        print(name_info)
    }
    
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
