//
//  UniversitiesViewController.swift
//  Malli_UniversityApp
//
//  Created by Malli,Bhavana on 4/20/23.
//

import UIKit

class Domain{
    var domainName : String?
    var universityName : [UniversityList]?
    
    init(domainName : String , universityName : [UniversityList]){
        self.domainName = domainName
        self.universityName = universityName
    }
}
var n = 0
class UniversitiesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return domaines.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universitiesTableView.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
        cell.textLabel?.text = domaines[indexPath.row].domain
        
        return cell
    }
    

    
    @IBOutlet weak var universitiesTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        universitiesTableView.delegate = self
        universitiesTableView.dataSource = self
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "listsSegue"{
            let destination = segue.destination as! UniversityListViewController
            destination.universities = domaines[(universitiesTableView.indexPathForSelectedRow?.row)!]
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
