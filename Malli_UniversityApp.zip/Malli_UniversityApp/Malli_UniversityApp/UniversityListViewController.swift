//
//  UniversityListViewController.swift
//  Malli_UniversityApp
//
//  Created by Malli,Bhavana on 4/20/23.
//

import UIKit

class college{
    var universityName : String?
    var universityimg : String?
    var universityinfo : String?
    
    init(universityName : String,universityimg : String,universityinfo : String){
        self.universityName = universityName;
        self.universityimg = universityimg;
        self.universityinfo = universityinfo;
    }
}
var img_name = ""
var desc = ""
var uni_name = ""
var unvrsty = [college]()

class UniversityListViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return domaines[0].list.count
    }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universityListTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        
        cell.textLabel?.text = universities?.list[indexPath.row].collegeName
        
        uni_name = (universities?.list[indexPath.row].collegeName)!
        
        img_name = (universities?.list[indexPath.row].collegeImage)!
        
        desc = (universities?.list[indexPath.row].collegeInfo)!
        var output = college(universityName: uni_name, universityimg: img_name, universityinfo: desc)
        unvrsty.append(output)
        print(img_name+"----------------------------"+desc+uni_name)
        
        return cell
    }

    @IBOutlet weak var universityListTableView: UITableView!
    
    var universities : Universities?
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = universities?.domain

        // Do any additional setup after loading the view.
        universityListTableView.delegate = self
        universityListTableView.dataSource = self
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           let transition = segue.identifier
        if(transition == "universityInfoSegue"){
            let destination = segue.destination as! UniversityInfoViewController
            destination.university = unvrsty[(universityListTableView.indexPathForSelectedRow?.row)!]
                          //destination.university = l
            //destination.lab = tableView(UITableView, cellForRowAt: IndexPath)
            //destination.nam = co
        }
        }

}


