//
//  ViewController.swift
//  HelloApp
//
//  Created by Malli,Bhavana on 1/24/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var NameInputOutlet: UITextField!
    
    
    @IBOutlet weak var displaylabelOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func buttnClicked(_ sender: UIButton) {
        //Read the input and store it(assign it to a variable.)
        var input = NameInputOutlet.text!
        
        //Perform String interpolation "Hello, name!" and assign it to display label
        displaylabelOutlet.text = "Hello, \(input)!!"
        
    }
    

}

