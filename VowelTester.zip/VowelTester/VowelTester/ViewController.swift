//
//  ViewController.swift
//  VowelTester
//
//  Created by Malli,Bhavana on 1/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var InputNameOutlet: UITextField!
    
    
    @IBOutlet weak var displayLabel1: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func SubmitButton(_ sender: UIButton) {
        
        var input = InputNameOutlet.text!
        
        if(input.contains("a")) || (input.contains("e")) || (input.contains("i")) || (input.contains("o")) || (input.contains("u")){
            
            displayLabel1.text = "The \(input) text has vowel😇"
            
        }
        else{
            
            displayLabel1.text = "The \(input) text has no vowel☹️"
        }


            
            
        }
    }
    



