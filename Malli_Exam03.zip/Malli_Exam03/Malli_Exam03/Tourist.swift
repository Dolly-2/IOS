//
//  Tourist.swift
//  Malli_Exam03
//
//  Created by Malli,Bhavana on 4/27/23.
//

import Foundation

struct TouristPlaces {
    var TouristName = ""
    var TouristImage = ""
    
}

let Tourist1 = TouristPlaces(TouristName : "Bryce Canyon", TouristImage : "Bryce Canyon")
let Tourist2 = TouristPlaces(TouristName : "Central Park", TouristImage : "Central Park")
let Tourist3 = TouristPlaces(TouristName : "Golden Gate", TouristImage : "Golden Gate")
let Tourist4 = TouristPlaces(TouristName : "Great Smoky Mountains", TouristImage : "Great Smoky Mountains")
let Tourist5 = TouristPlaces(TouristName : "Navy Pier", TouristImage : "Navy Pier")
let Tourist6 = TouristPlaces(TouristName : "StatueOfLiberty", TouristImage : "StatueOfLiberty")

var Tourist = [Tourist1, Tourist2, Tourist3, Tourist4,Tourist5,Tourist6]


