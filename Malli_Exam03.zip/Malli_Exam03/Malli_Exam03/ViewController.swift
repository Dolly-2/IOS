//
//  ViewController.swift
//  Malli_Exam03
//
//  Created by Malli,Bhavana on 4/27/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Tourist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableViewOutlet.dequeueReusableCell(withIdentifier: "tableCell", for: indexPath)
        cell.textLabel?.text = Tourist[indexPath.row].TouristName
        return cell
    }
    
    
    
    @IBOutlet weak var tableViewOutlet: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableViewOutlet.delegate = self
        tableViewOutlet.dataSource = self
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        let transition = segue.identifier
                if transition == "Tourist Segue"{
                    let destination = segue.destination as! ResultViewController
                    destination.placeImage = Tourist[(tableViewOutlet.indexPathForSelectedRow?.row)!].TouristImage
                    
                    destination.placeNmae = Tourist[(tableViewOutlet.indexPathForSelectedRow?.row)!].TouristName
                }
        
        
    }


}

