//
//  ResultViewController.swift
//  Malli_Exam03
//
//  Created by Malli,Bhavana on 4/27/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var displayLabel: UILabel!
    
    
    @IBOutlet weak var ImageOutlet: UIImageView!
    
    var placeImage = ""
    var placeNmae = ""
    
    @IBAction func ClickMe(_ sender: UIButton) {
        UIView.animate(withDuration: 2, animations: {
                    self.ImageOutlet.alpha = 0
                })

                UIView.animate(withDuration: 2, delay:0, animations: {
                            self.ImageOutlet.alpha = 1
                    self.ImageOutlet.image = UIImage(named: self.placeImage)
                    
                        })
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ImageOutlet.image = UIImage(named: placeImage)
        displayLabel.text = placeNmae
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
