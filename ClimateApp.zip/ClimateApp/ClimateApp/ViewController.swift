//
//  ViewController.swift
//  ClimateApp
//
//  Created by Malli,Bhavana on 2/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var tempInput: UITextField!
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func displayImage(_ sender: Any) {
        
        if(tempInput.text == "-15"){
            imageViewOL.image = UIImage(named: "Snow")
            
        }
        else if(tempInput.text == "65"){
            imageViewOL.image = UIImage(named: "Sunny")
            
        }
        else {
            imageViewOL.image = UIImage(named: "Rain")
            
            
        }
    }
    

}

