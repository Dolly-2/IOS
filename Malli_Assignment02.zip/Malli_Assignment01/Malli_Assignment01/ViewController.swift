//
//  ViewController.swift
//  Malli_Assignment01
//
//  Created by Malli,Bhavana on 1/27/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var FirstNameOutlet: UITextField!
    
    
    @IBOutlet weak var LastNameOutlet: UITextField!
    
    
    @IBOutlet weak var yearOutlet: UITextField!

    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    
    @IBOutlet weak var ageLabel: UILabel!
    
    
    @IBOutlet weak var detailsLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func SubmitBTN(_ sender: UIButton) {
        var input1 = FirstNameOutlet.text!
        var input2 = LastNameOutlet.text!
        var input3 = yearOutlet.text!
        var input4 = Int(input3)
        var input5 = Int(input3) ?? 0
        var year = Calendar.current.component(.year, from: Date())
        var input6 = year-input5
        
       // var input4 = 2023 - input3
 fullNameLabel.text = "Full Name : \(input1) \(input2)"
        initialsLabel.text = "initials : \(input2.first!) \(input1.first!)"
 ageLabel.text = " Age : \(input6)"
}
    
    
    @IBAction func ResetBTN(_ sender: UIButton) {
        FirstNameOutlet.text = ""
        LastNameOutlet.text = ""
        yearOutlet.text = ""
        fullNameLabel.text = ""
        initialsLabel.text = ""
        ageLabel.text = ""
        detailsLabel.text = ""
        }
    

}


