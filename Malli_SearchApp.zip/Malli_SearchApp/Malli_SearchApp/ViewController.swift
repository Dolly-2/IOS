//
//  ViewController.swift
//  Malli_SearchApp
//
//  Created by Malli,Bhavana on 3/22/23.
//

import UIKit

class ViewController: UIViewController {
    
    let actor_keywords = ["actor","hero","movie","song"]
    let car_keywords = ["fourwheeler","automobile","sportscar","car"]
    let food_keywords = ["veg","deserts","non-veg","mexican"]
    let keyword = "not valid"
    

    var arr = [["Aditya Roy Kapoor","Prabhas","PriyankaC","Ranbhir","Ranveer Singh"], ["Audi","BMW","Bugati", "Rollsroyce","Volvo"] , ["Avocado Chicken Burger","IceCream","Mutton Biryani","Pizza","Shrimp"]]
    var topics_array = [["Aditya Roy Kapur is an Indian actor who works predominantly in Hindi films. He made his acting debut in 2009 with the musical drama film London Dreams","Uppalapati Venkata Suryanarayana Prabhas Raju, known mononymously as Prabhas, is an Indian actor who works predominantly in Telugu cinema.","Priyanka Chopra Jonas is an Indian actress and producer. The winner of the Miss World 2000 pageant, Chopra is one of India's highest-paid actresses and has received numerous accolades, including two National Film Award and five Filmfare Awards","Ranbir Kapoor is an Indian actor known for his work in Hindi-language films. He is one of the highest-paid actors of Hindi cinema and has featured in Forbes India's Celebrity 100 list since 2012","Ranveer Singh Bhavnani is an Indian actor who works in Hindi films. The recipient of several awards, including five Filmfare Awards, he is among the highest-paid Indian actors and has been featured in Forbes India's Celebrity 100 list since 2012"],["Audi AG is a German automotive manufacturer of luxury vehicles headquartered in Ingolstadt, Bavaria, Germany.","Bayerische Motoren Werke AG, abbreviated as BMW, is a German multinational manufacturer of luxury vehicles and motorcycles headquartered in Munich, Bavaria.","The Bugatti Veyron EB 16.4 is a mid-engine sports car, designed and developed in Germany by the Volkswagen Group and Bugatti and manufactured in Molsheim, France, by French automobile manufacturer Bugatti. It was named after the racing driver Pierre Veyron.","Rolls-Royce was a British luxury car and later an aero-engine manufacturing business established in 1904 in Manchester by the partnership of Charles Rolls and Henry Royce.","Volvo's subcompact XC40 SUV brings plenty of style, safety, and practicality at a starting point of just under $38,000. The most affordable Volvo car is the S60 sedan, which starts around $42,000."],["A sandwich consisting of a patty made from ground chicken, served in a bun, typically hot and often with other ingredients. The chicken patty used in such a sandwich.","Ice cream is a frozen dessert, typically made from milk or cream and flavoured with a sweetener, either sugar or an alternative, and a spice, such as cocoa or vanilla, or with fruit such as strawberries or peaches.","Biryani is a mixed rice dish originating among the Muslims of the Indian subcontinent. It is made with Indian spices, rice, and usually some type of meat (chicken, beef, goat, lamb, prawn, and fish).","Pizza was first created by the Baker named Raffeale Esposito in Naples, Italy. He was willing to invent Pizza which is totally different from other Types of Pizzas in Naples. He first came up with the idea of savoring the Pizza with cheese.","This is a dish prepared with shrimp (locally also referred to as prawn), typically cooked in a thick sauce of a yellow hue. Among other ingredients are grated coconut, turmeric, cumin, coriander, chilli, onion, garlic, tamarind, vinegar, sugar and salt."]]
    
    var topic = -1
    
    
    @IBOutlet weak var searchTextField: UITextField!
    
    
    
    @IBAction func searchAction(_ sender: Any) {
        if(searchTextField.text == ""){
            SearchBtn.isEnabled = false
            PreBtn.isHidden = true
            NextBtn.isHidden = true
            ReBtn.isHidden = true
            topicInfoText.text = " "
            }
        else{
            SearchBtn.isEnabled = true
            resultImage.image = UIImage()
            
            
        }
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        var Find : String = searchTextField.text!
        
        PreBtn.isHidden = false
        NextBtn.isHidden = false
        ReBtn.isHidden = false
        PreBtn.isEnabled = false
        

        //to search a non keyword
        if (searchTextField.text == keyword){
            resultImage.image = UIImage(named: "Robot")
            topicInfoText.text = ""
            PreBtn.isHidden = true
            NextBtn.isHidden = true
            ReBtn.isHidden = true
            
        }
    
        else if(actor_keywords.contains(Find) ){
            //displaying that image
            topic = 0
            resultImage.image = UIImage(named: arr[topic][0])
            topicInfoText.text = topics_array[topic][0]
            }
        else if(car_keywords.contains(Find)){
            topic = 1
            resultImage.image = UIImage(named: arr[topic][0])
            topicInfoText.text = topics_array[topic][0]
        }
        else if(food_keywords.contains(Find)){
        topic = 2
            
            resultImage.image = UIImage(named: arr[topic][0])
            topicInfoText.text = topics_array[topic][0]
        }
        else{
            resultImage.image = UIImage(named: "Robot")
            topicInfoText.text = ""
            PreBtn.isHidden = true
            NextBtn.isHidden = true
            ReBtn.isHidden = true
            
            
        }
        
        
    }
    
    @IBOutlet weak var resultImage: UIImageView!
    
    
    @IBOutlet weak var SearchBtn: UIButton!
    
    
    @IBOutlet weak var PreBtn: UIButton!
    
    
    @IBOutlet weak var NextBtn: UIButton!
    
    var imageNumber = 0
    
    @IBOutlet weak var ReBtn: UIButton!
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
    NextBtn.isEnabled = true

     //once you reach starting of array disable the previous btn
        if(imageNumber == 1){
            PreBtn.isEnabled = false
            imageNumber = 0
            resultImage.image = UIImage(named: arr[topic][imageNumber])
            topicInfoText.text = topics_array[topic][imageNumber]
            
        }
        else{
            imageNumber -= 1
            resultImage.image = UIImage(named: arr[topic][imageNumber])
            topicInfoText.text = topics_array[topic][imageNumber]
            PreBtn.isEnabled = true
            
            }

        
        
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        searchTextField.text = ""
        SearchBtn.isEnabled = false
        PreBtn.isHidden = true
        NextBtn.isHidden = true
        ReBtn.isHidden = true
        resultImage.image = UIImage(named: "Welcome")
        topicInfoText.text = ""
        
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        
        //increment the image number
        imageNumber += 1
        
        //when we reach the end of array next button should be disabled
        if(imageNumber == arr[topic].count-1){
            //reach the end of array
            NextBtn.isEnabled = false
            resultImage.image = UIImage(named: arr[topic][imageNumber])
            topicInfoText.text = topics_array[topic][imageNumber]
        }
        else{
            resultImage.image = UIImage(named: arr[topic][imageNumber])
            topicInfoText.text = topics_array[topic][imageNumber]
            //NextBtn.isEnabled = true
            PreBtn.isEnabled = true
        }

        
    }
    
    @IBOutlet weak var topicInfoText: UITextView!
    
   override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        SearchBtn.isEnabled = false
        PreBtn.isHidden = true
        NextBtn.isHidden = true
        ReBtn.isHidden = true
        resultImage.image = UIImage(named: "Welcome")
        topicInfoText.text = " "
    }


}

