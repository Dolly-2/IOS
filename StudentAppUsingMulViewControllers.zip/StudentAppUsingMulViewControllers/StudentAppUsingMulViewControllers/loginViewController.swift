//
//  ViewController.swift
//  StudentAppUsingMulViewControllers
//
//  Created by Malli,Bhavana on 4/4/23.
//

import UIKit

class loginViewController: UIViewController {
    
    
    @IBOutlet weak var sIdOutlet: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func loginButtonAction(_ sender: Any) {
    }
    

}

