//
//  Student.swift
//  StudentAppUsingMulViewControllers
//
//  Created by Malli,Bhavana on 4/4/23.
//

import Foundation

struct Student{
    
    var name = ""
    var sid = ""
    var email = ""
    
    var courses:[Course] = []
    
}

struct Course{
    
    var title = ""
    var sem = ""
}

let student1 = Student(name:"Bhavana",sid:"s555841",email: "s555841@gmail.com",
                     courses:[
                        Course(title:"Mobile Computing",sem:"sp23"),
                        Course(title:"Data Structures",sem:"sp23"),
                        Course(title:"Big Data",sem:"sp23")
                     ])

let student2 = Student(name: "Tejo",sid: "s555840",email: "s555840@gmail.com",
                        courses:[
                            Course(title: "patterns",sem: "sp23"),
                            Course(title: "java",sem: "fall22"),
                            Course(title: "Data Base",sem: "fall22")
                        ])

let student3 = Student(name: "Cherry",sid: "s550593",email: "s550593@gmail.com",
                courses:[
                Course(title: "Bigdata",sem: "fall23"),
                Course(title: "webapps",sem: "fall22"),
                Course(title: "project Management",sem: "fall23")
                ])

let students = [student1,student2,student3]
