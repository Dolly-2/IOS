//
//  ViewController.swift
//  SamplePracticeApp
//
//  Created by Malli,Bhavana on 1/26/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var course1Inputoutlet: UITextField!
    
    
    @IBOutlet weak var course2Inputoutlet: UITextField!
    
    @IBOutlet weak var displayOutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func ButtonClicked(_ sender: Any) {
        //Read the course1 name and store it in variable.
        var input1 =  course1Inputoutlet.text!
        //Read the course2 name and store it in variable.
        var input2 = course2Inputoutlet.text!
        //perfom String interpolation and assign display label.(course1-course2)
        
        
displayOutlet.text = "\(input1) -   \(input2)"
        
        
        
        
    }
    

}

