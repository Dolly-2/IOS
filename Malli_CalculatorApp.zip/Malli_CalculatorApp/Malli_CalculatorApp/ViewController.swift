//
//  ViewController.swift
//  Malli_CalculatorApp
//
//  Created by Malli,Bhavana on 2/16/23.
//

import UIKit

class ViewController: UIViewController {
    var A:String = " "
    var B:String = " "
    var C:Character = " ";

    @IBOutlet weak var resultOutlet: UILabel!
    
    @IBAction func buttonAC(_ sender: UIButton) {
        resultOutlet.text=""
                A = " "
                B = " "
                C = " "
    }
    
    @IBAction func buttonC(_ sender: UIButton) {
        if(B != " "){
        B=String(B[B.startIndex..<B.index(B.endIndex,offsetBy: -1)])
                    
                    resultOutlet.text=B
                    
                }
                
        else if(A != " "){
          A=String(A[A.startIndex..<A.index(A.endIndex,offsetBy: -1)])
                    resultOutlet.text=A
                    
                }
    }
    
   
    @IBAction func buttonsignchange(_ sender: UIButton) {
        if(B != " "){
        if(B.contains(".")){
                       B = "\(-Double(B)!)"
                       resultOutlet.text=B
                   }
        else{
        B = "\(-Int(B)!)"
        resultOutlet.text=B
                   }
                   
               }
               else if(A != " ") {
                   if(A.contains(".")){
                       A = "\(-Double(A)!)"
                       resultOutlet.text=A
                   }
                   else{
                       A = "\(-Int(A)!)"
                       resultOutlet.text=A
                   }
               }
               
    }
    
    @IBAction func buttondivision(_ sender: UIButton) {
        C="/"
    }
    
    @IBAction func buttonseven(_ sender: UIButton) {
        if (A == " " && C == " " ){
                   A="7"
                   resultOutlet.text="\(A)"
               }else if(A != " " && C == " " ){
                   A=A+"7"
                   resultOutlet.text="\(A)"
               }
               else if(B == " " && C != " "){
                   B = "7"
                   resultOutlet.text="\(B)"
               }
               else if(B != " "){
                   B=B+"7"
                   resultOutlet.text="\(B)"
               }
    }
    
    @IBAction func buttoneight(_ sender: UIButton) {
        if (A == " " && C == " " ){
                    A="8"
                    resultOutlet.text="\(A)"
                }else if(A != " " && C == " " ){
                    A=A+"8"
                    resultOutlet.text="\(A)"
                }
                else if(B == " " && C != " "){
                    B = "8"
                    resultOutlet.text="\(B)"
                }
                else if(B != " "){
                    B=B+"8"
                    resultOutlet.text="\(B)"
                }
    }
    
    @IBAction func buttonnine(_ sender: UIButton) {
        if (A == " " && C == " " ){
                   A="9"
                   resultOutlet.text="\(A)"
               }else if(A != " " && C == " " ){
                   A=A+"9"
                   resultOutlet.text="\(A)"
               }
               else if(B == " " && C != " "){
                   B = "9"
                   resultOutlet.text="\(B)"
               }
               else if(B != " "){
                   B=B+"9"
                   resultOutlet.text="\(B)"
               }
    }
    
    @IBAction func buttonmultiplication(_ sender: UIButton) {
        C="*"
    }
    
    @IBAction func buttonfour(_ sender: UIButton) {
        if (A == " " && C == " " ){
                   A="4"
                   resultOutlet.text="\(A)"
               }else if(A != " " && C == " " ){
                   A=A+"4"
                   resultOutlet.text="\(A)"
               }
               else if(B == " " && C != " "){
                   B = "4"
                   resultOutlet.text="\(B)"
               }
               else if(B != " "){
                   B=B+"4"
                   resultOutlet.text="\(B)"
               }
    }
    
    @IBAction func buttonfive(_ sender: UIButton) {
        if (A == " " && C == " " ){
                    A="5"
                    resultOutlet.text="\(A)"
                }else if(A != " " && C == " " ){
                    A=A+"5"
                    resultOutlet.text="\(A)"
                }
                else if(B == " " && C != " "){
                    B = "5"
                    resultOutlet.text="\(B)"
                }
                else if(B != " "){
                    B=B+"5"
                    resultOutlet.text="\(B)"
                }
    }
    
    @IBAction func buttonsix(_ sender: UIButton) {
        if (A == " " && C == " " ){
                   A="6"
                   resultOutlet.text="\(A)"
               }else if(A != " " && C == " " ){
                   A=A+"6"
                   resultOutlet.text="\(A)"
               }
               else if(B == " " && C != " "){
                   B = "6"
                   resultOutlet.text="\(B)"
               }
               else if(B != " "){
                   B=B+"6"
                   resultOutlet.text="\(B)"
               }
    }
    
    @IBAction func buttonsub(_ sender: UIButton) {
        C="-"
    }
    
    @IBAction func buttonone(_ sender: UIButton) {
        if (A == " " && C == " " ){
                   A="1"
                   resultOutlet.text="\(A)"
               }else if(A != " " && C == " " ){
                   A=A+"1"
                   resultOutlet.text="\(A)"
               }
               else if(B == " " && C != " "){
                   B = "1"
                   resultOutlet.text="\(B)"
               }
               else if(B != " "){
                   B=B+"1"
                   resultOutlet.text="\(B)"
               }
               
    }
    
    @IBAction func buttontwo(_ sender: UIButton) {
        if (A == " " && C == " " ){
                   A="2"
                   resultOutlet.text="\(A)"
               }else if(A != " " && C == " " ){
                   A=A+"2"
                   resultOutlet.text="\(A)"
               }
               else if(B == " " && C != " "){
                   B = "2"
                   resultOutlet.text="\(B)"
               }
               else if(B != " "){
                   B=B+"2"
                   resultOutlet.text="\(B)"
               }
    }
    
    @IBAction func buttonthree(_ sender: UIButton) {
        if (A == " " && C == " " ){
                   A="3"
                   resultOutlet.text="\(A)"
               }else if(A != " " && C == " " ){
                   A=A+"3"
                   resultOutlet.text="\(A)"
               }
               else if(B == " " && C != " "){
                   B = "3"
                   resultOutlet.text="\(B)"
               }
               else if(B != " "){
                   B=B+"3"
                   resultOutlet.text="\(B)"
               }
    }
    
    
    @IBAction func buttonadd(_ sender: UIButton) {
        C="+"
    }
    
    
    @IBAction func buttonzero(_ sender: UIButton) {
        if (A == " " && C == " " ){
                   A="0"
                   resultOutlet.text="\(A)"
               }else if(A != " " && C == " " ){
                   A=A+"0"
                   resultOutlet.text="\(A)"
               }
               else if(B == " " && C != " "){
                   B = "0"
                   resultOutlet.text="\(B)"
               }
               else if(B != " "){
                   B=B+"0"
                   resultOutlet.text="\(B)"
               }
    }
    
    @IBAction func buttondecimal(_ sender: UIButton) {
        if(A == " " && C == " "){
                    A="0."
                    resultOutlet.text="\(A)"
                }else if(A != " " && C == " "){
                    A=A+"."
                    resultOutlet.text="\(A)"
                }
                else if(B == " " && C != " "){
                    B="0."
                    resultOutlet.text="\(B)"
                }else if(B != " "){
                    B=B+"."
                    resultOutlet.text="\(B)"
                }
    }
    
    @IBAction func buttonpercentage(_ sender: UIButton) {
        C="%"
    }
    
    @IBAction func buttonequals(_ sender: UIButton) {
        switch C{
                case "+" :
                    if(A.contains(".")){
                        let val = "\(Double(A)! + Double(B)!)"
                        let firstInd=val.firstIndex(of: ".")!.utf16Offset(in: val)
                        let dec = val[val.index(val.startIndex,offsetBy: firstInd+1)]
                        if(dec != "0"){
                            resultOutlet.text = val
                        }
                        else{
                            resultOutlet.text = "\(Int(Double(A)! + Double(B)!))"
                        }
                        
                    }
                    else {
                        resultOutlet.text = "\(Int(A)! + Int(B)!)"
                    }
                    
                    
                case "-" :
                 
                    if(A.contains(".")){
                        resultOutlet.text = "\(Double(A)! - Double(B)!)"
                    }
                    else {
                        resultOutlet.text = "\(Int(A)! - Int(B)!)"
                    }
                
                case "*" :
                    if(A.contains(".")){
                        resultOutlet.text = "\(Double(A)! * Double(B)!)"
                    }
                    else {
                        resultOutlet.text = "\(Int(A)! * Int(B)!)"
                    }
                    
                case "/" :
                    if(A.contains(".")){
                        resultOutlet.text = "\(Double(A)! / Double(B)!)"
                    }
                    else {
                        if(B == "0"){
                            resultOutlet.text = "Not a number"
                        }
                        else{
                            let val = "\(Double(A)! / Double(B)!)"
                            let firstInd=val.firstIndex(of: ".")!.utf16Offset(in: val)
                            let dec = val[val.index(val.startIndex,offsetBy: firstInd+1)]
                            if(dec != "0"){
                                resultOutlet.text = "\(round(Double(val)!*100000)/100000)"
                            }
                            else{
                                resultOutlet.text = "\(Int(A)! / Int(B)!)"
                            }
                        }
                        
                    }
                    
                case "%" :
                    
                    if(A.contains(".")){
                        let val = Double(A)!.truncatingRemainder(dividingBy: Double(B)!)
                        resultOutlet.text = "\(round(val*10)/10)"
                    }
                    else {
                        resultOutlet.text = "\(Int(A)! % Int(B)!)"
                    }
                
                    
                default:
                    print("no operation")
             
                
               }
    }
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        //self.resultOutlet.isEnabled = true;
        // Do any additional setup after loading the view.
    }


}

