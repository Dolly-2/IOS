//
//  ViewController.swift
//  ExamPractice
//
//  Created by Malli,Bhavana on 4/10/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var heightOutlet: UITextField!
    
    
    @IBOutlet weak var weightOutlet: UITextField!
    
    var bmiIndex = 0.0
    var ResultImage = ""
    var resultLabel = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func buttnBMI(_ sender: Any) {
        var height = Double(heightOutlet.text!) ?? 1.0
        var weight = Double(weightOutlet.text!) ?? 0.0
        
        bmiIndex = round((weight / (pow(height,2)))*10)/10
        
        ResultImage = "bmi"
        
        if (25 <= bmiIndex && bmiIndex <= 30){
            resultLabel = "Your BMI Index is \(bmiIndex). It says that you have Over Weight"
        }
        else if (bmiIndex < 18.5){
            resultLabel = "Your BMI Index is \(bmiIndex). It says that you have Under Weight"
        }
        else if (18.5 <= bmiIndex && bmiIndex <= 24.5){
            resultLabel = "Your BMI Index is \(bmiIndex). It says that you have Normal Weight"
        }
        else if (35 <= bmiIndex && bmiIndex <= 39.5){
            resultLabel = "Your BMI Index is \(bmiIndex). It says that you have Severe Obesity"
        }
        else if (40 <= bmiIndex && bmiIndex <= 44.5){
            resultLabel = "Your BMI Index is \(bmiIndex). It says that you have morbid obesity"
        }
        
        else if (45 <= bmiIndex && bmiIndex <= 50){
            resultLabel = "Your BMI Index is \(bmiIndex). It says that you have Super Obesity"
        }
    
        else{
            ResultImage = "error"
            resultLabel = "Enter Valid ddtails"
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        
        var transition = segue.identifier
        
        if transition == "ResultSegue"{
            var destination = segue .destination as!
                BMIViewController
            
            destination.outputImage = ResultImage
            destination.result = resultLabel
            
            heightOutlet.text = ""
            weightOutlet.text = ""
        }
        
    }
    
    


}

